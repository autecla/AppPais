package com.lincs.mobcare.evolution;

import android.support.v4.app.DialogFragment;

public class EvolutionComment extends DialogFragment {


}
