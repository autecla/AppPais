package com.lincs.mobcare.daily;

/**
 * Created by Lincs on 09/02/2017.
 */

public interface AdapterCallback {
    void onMethodCallback();
}